package com.domain;

public class Member {

}
