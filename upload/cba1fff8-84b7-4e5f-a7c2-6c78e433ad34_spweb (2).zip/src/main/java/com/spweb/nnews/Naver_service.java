package com.spweb.nnews;

public class Naver_service {
	// 주제와 검색어 전달시 네이버 결과 json을 리턴
	
}
