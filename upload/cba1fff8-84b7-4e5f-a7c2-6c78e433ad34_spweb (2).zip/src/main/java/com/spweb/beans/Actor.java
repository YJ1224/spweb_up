package com.spweb.beans;

import java.util.Calendar;
import java.util.Date;

public class Actor {
	// 초기
	private String name;
	private String birth;
	// getter / setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	
}
