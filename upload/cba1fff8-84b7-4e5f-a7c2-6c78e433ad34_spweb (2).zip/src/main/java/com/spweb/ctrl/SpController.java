package com.spweb.ctrl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spweb.beans.Actor;
import com.spweb.beans.Movie;
import com.spweb.nnews.Napi;

@Controller
public class SpController {

	@Inject
	private SqlSession session;

	@RequestMapping(value = "/insert_test", method = RequestMethod.GET)
	public String insertMembertest() {
		session.insert("org.mapper.BoardMapper.insert");
		return "actor_form";
	}
	
	
	@RequestMapping(value = "/proc_number/{bno}", method = RequestMethod.GET)
	public String procNumber(@PathVariable Integer bno) {
		if (Objects.isNull(bno)) {
			bno = 1;
		}

		// �뀒�뒪�듃
		System.out.println(bno);

		// forward
		return "test/proc_number";
	}

	@RequestMapping(value = "/actor_send", method = RequestMethod.POST)
	public String sendActor(Actor a, Model m, HttpServletRequest r) {
		System.out.println(a.getBirth());
		// setAttr
		m.addAttribute("a", a);
		//
		return "actor_view";
	}

	@RequestMapping(value = "/actor_form", method = RequestMethod.GET)
	public String goActionForm() {
		return "actor_form";
	}

	@RequestMapping(value = "/movie_type", method = RequestMethod.POST)
	public String postMovieType(Movie mv, Model m, HttpServletRequest r) {
		System.out.println(mv.getTitle());

		// setAttr
		m.addAttribute("mv", mv);
		//
		return "view_movie";
	}

	@RequestMapping(value = "/form_movie_type", method = RequestMethod.GET)
	public String getMovieType() {
		return "form_movie_type";
	}

	@RequestMapping(value = "/search_naver", method = RequestMethod.GET)
	public String searchNaver() {
		return "search_naver";
	}

	@RequestMapping(value = "/home_nnews", method = RequestMethod.GET)
	public ResponseEntity<String> getNnews(Model m, HttpServletRequest r, HttpServletResponse res) {
		// 珥덇린
		HttpHeaders resHeader = new HttpHeaders();
		resHeader.add("Content-Type", "application/json; charset=UTF-8");

		Object theme = r.getParameter("theme");
		theme = Objects.isNull(theme) ? "news" : theme;
		Object query = r.getParameter("query");
		query = Objects.isNull(query) ? "�씠�뒋" : query;
		System.out.println(theme);
		System.out.println(query);

		//
		return new ResponseEntity<String>(Napi.getJson(theme.toString(), query.toString()), resHeader,
				HttpStatus.CREATED);
	}

	@RequestMapping(value = "/movie", method = RequestMethod.POST)
	public String postMovie(Model m, HttpServletRequest r) {
		// 珥덇린
		try {
			r.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> ms = new ArrayList<>();
		HashMap<String, String> hm = null;
		// �엯�젰
		hm = new HashMap<>();
		hm.put("title", "踰좊냸");
		hm.put("director", "�넱�븯�뵒");
		ms.add(hm);
		hm = new HashMap<>();
		hm.put("title", "�븫�닔�궡�씤");
		hm.put("director", "源��깭洹�");
		ms.add(hm);
		hm = new HashMap<>();
		hm.put("title", r.getParameter("title"));
		hm.put("director", r.getParameter("director"));
		ms.add(hm);
		// setAttribute
		m.addAttribute("ms", ms);
		// View Return
		return "list_movie";
	}

	@RequestMapping(value = "/movie", method = RequestMethod.GET)
	public String getMovie() {
		return "form_movie";
	}

	@RequestMapping(value = "/show_message", method = RequestMethod.GET)
	public String showMessage(Model m) {
		// 紐⑤뜽�뿉 �뜲�씠�꽣 異붽�
		m.addAttribute("message", "硫붿꽭吏�");

		// VIEW�쓽 jsp�뙆�씪 �뙆�씪�씠由꾩쓣 由ы꽩
		return "showMessage";
	}

	@RequestMapping(value = "/add_array", method = RequestMethod.GET)
	public String addArray(Model m) {
		// 珥덇린
		ArrayList<HashMap<String, String>> mems = new ArrayList<>();
		HashMap<String, String> mem = null;
		// 議곗씤�꽦
		mem = new HashMap<>();
		mem.put("name", "議곗씤�꽦");
		mem.put("age", "40");
		mems.add(mem);
		// �궓二쇳쁺
		mem = new HashMap<>();
		mem.put("name", "�궓二쇳쁺");
		mem.put("age", "31");
		mems.add(mem);
		// �꽕�쁽
		mem = new HashMap<>();
		mem.put("name", "�꽕�쁽");
		mem.put("age", "25");
		mems.add(mem);

		// 紐⑤뜽�뿉 �뜲�씠�꽣 異붽�
		m.addAttribute("mems", mems);

		// VIEW�쓽 jsp�뙆�씪 �뙆�씪�씠由꾩쓣 由ы꽩
		return "add_array";
	}

	@RequestMapping(value = "/list_movie", method = RequestMethod.GET)
	public String listMovie(Model m) {
		// 珥덇린
		ArrayList<Movie> ms = new ArrayList<>();
		Movie mv = null;
		// 1
		mv = new Movie();
		mv.setTitle("�븞�떆�꽦");
		mv.setPoint(8.10);
		mv.setDirector("源�愿묒떇");
		ms.add(mv);
		// 2
		mv = new Movie();
		mv.setTitle("紐낅떦");
		mv.setPoint(7.98);
		mv.setDirector("�씠醫낆꽍");
		ms.add(mv);
		// 3
		mv = new Movie();
		mv.setTitle("�삊�긽");
		mv.setPoint(7.34);
		mv.setDirector("諛뺥씗怨�");
		ms.add(mv);

		// 紐⑤뜽�뿉 �뜲�씠�꽣 異붽�
		m.addAttribute("ms", ms);

		// VIEW�쓽 jsp�뙆�씪 �뙆�씪�씠由꾩쓣 由ы꽩
		return "list_movie";
	}

}
