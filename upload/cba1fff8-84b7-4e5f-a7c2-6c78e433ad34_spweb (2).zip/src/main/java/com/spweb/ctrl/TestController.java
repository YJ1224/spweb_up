package com.spweb.ctrl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spweb.beans.Actor;
import com.spweb.beans.Movie;
import com.spweb.nnews.Napi;

@Controller
@RequestMapping(value = "/test")
public class TestController {
	@RequestMapping(value = "/proc_number/{bno}", method = RequestMethod.GET)
	public String procNumber(@PathVariable Integer bno, Model mo) {
		// 초기
		ArrayList<Movie> ms = new ArrayList<>();
		Movie m = null;
		// 베놈
		m = new Movie(); m.setTitle("베놈"); m.setPoint(8.47);
		m.setDirector("톰하디");
		ms.add(m);
		// 암수살인
		m = new Movie(); m.setTitle("암수살인"); m.setPoint(8.6);
		m.setDirector("김태균");
		ms.add(m);
		// 안시성
		m = new Movie(); m.setTitle("안시성"); m.setPoint(8.65);
		m.setDirector("김광식");
		ms.add(m);
		
		// setAtt
		HashMap<String, Object> state = new HashMap<>();
		state.put("msg", "조회결과");
		state.put("code", 1);
		try {
			m = ms.get(bno);
		} catch (Exception e) {
			state.put("msg", "잘못된 조회입니다.");
			state.put("code", 0);
		}
		mo.addAttribute("m", m);
		mo.addAttribute("state", state);
		
		// 테스트
		System.out.println(state.get("code"));
		
		// forward
		return "test/proc_number";
	}
}
