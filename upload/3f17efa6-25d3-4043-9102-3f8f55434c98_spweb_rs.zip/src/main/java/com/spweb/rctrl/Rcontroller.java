package com.spweb.rctrl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spweb.beans.Rbean;

@RestController  // 레스트서비스위 한 컨트롤러
@RequestMapping("/basic")
public class Rcontroller {
	
	// 첫번재 레스트서비스
	@RequestMapping(value ="/string", produces="text/plain;charset=UTF-8")
	public String makeString() {
		return "베이직";
	}
	// 자바빈인경우
	@RequestMapping("/bean")
	public Rbean makeRbean() {
		return new Rbean("홍길동", 27);
	}
	// 리스트인경우
	@RequestMapping("/list")
	public List<String> makeList() {
		return Arrays.asList("모탈컴벳11", "세키로", "피파4");
	}
	
	// 맵인경우
	@RequestMapping("/map")
	public HashMap<String, String> makeMap() {
		return new HashMap<String, String>() {{
			put("말모이", "엄유나");
			put("글래스", "나이트샤말란");
			put("내안의그놈", "강효진");
		}};
	}
	
	// 맵인경우
	@RequestMapping("/set")
	public HashSet<String> makeSet() {
		return new HashSet<String>(Arrays.asList("카풀", "4차산업혁명", "카택"));
	}
	
	// 
	
}
