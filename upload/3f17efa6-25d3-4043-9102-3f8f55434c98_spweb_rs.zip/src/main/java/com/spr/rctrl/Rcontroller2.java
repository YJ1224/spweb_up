package com.spr.rctrl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spr.service.Rservice;
import com.spweb.beans.Rbean;

@RestController  // 레스트서비스위 한 컨트롤러
@RequestMapping("/spr_t")
public class Rcontroller2 {
	// 변수
	@Autowired
	Rservice rs;
	
	// 맵인경우
	@RequestMapping("/sel_spr")
	public ArrayList<HashMap<String, String>> makeMap() {
		return rs.list();
	}
	
}
