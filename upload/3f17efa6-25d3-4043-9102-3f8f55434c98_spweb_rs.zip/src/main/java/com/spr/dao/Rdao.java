package com.spr.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Component;

import commons.Db;

@Component
public class Rdao {
	// select method
	public ArrayList<HashMap<String, String>> select() {
		return Db.selectListMap("SELECT * FROM spr_test2 ORDER BY S_NUM DESC");
	}
}
