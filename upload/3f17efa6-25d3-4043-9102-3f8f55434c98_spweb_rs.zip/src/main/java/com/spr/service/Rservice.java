package com.spr.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spr.dao.Rdao;

@Component
public class Rservice {
	@Autowired
	Rdao rd;
	
	// 목록
	public ArrayList<HashMap<String, String>> list() {
		return rd.select();
	}
}
